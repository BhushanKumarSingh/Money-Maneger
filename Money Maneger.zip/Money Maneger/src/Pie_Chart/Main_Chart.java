package Pie_Chart;
import javax.swing.JFrame;

public class Main_Chart {
	
	public static void main(String [] bks)
	{
		CreateChart cc=new CreateChart("Pie Chart", "Income , Expense , Remaining");
		cc.pack();
		cc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cc.setVisible(true);
	}
	

}
