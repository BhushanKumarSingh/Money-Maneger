package Pie_Chart;
import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

public class CreateChart extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CreateChart(String appTitle,String chartTitle)
	{
		PieDataset dataset =createDataset();
		JFreeChart chart =createChart(dataset,chartTitle);
		ChartPanel chartPanel =new ChartPanel(chart);
		chartPanel.setPreferredSize(new java.awt.Dimension(500,300));
		setContentPane(chartPanel);
	}

	private JFreeChart createChart(PieDataset dataset, String title) {
		JFreeChart chart=ChartFactory.createPieChart(title, dataset, true, true, false);
		
		PiePlot3D plot=(PiePlot3D) chart.getPlot();	
		plot.setStartAngle(0);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha((float) 0.5);
		return chart;
		
	}

	private PieDataset createDataset() {
		DefaultPieDataset result=new DefaultPieDataset();
		result.setValue("Income",1000);
		result.setValue("EXpense", 500);
		result.setValue("Remaining", 400);
		
		return result;
		
		
		
		
	}

}

